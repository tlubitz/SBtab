## additional scripts
This folder contains a number of files, that are being called by the excel add-in. 